#ifndef _NEUTON_COMMONS_H_
#define _NEUTON_COMMONS_H_

#include <neuton/neuton_types.h>

#include "neuton_c_intrinsics.h"
#include "neuton_defs.h"

#endif /* _NEUTON_COMMONS_H_ */