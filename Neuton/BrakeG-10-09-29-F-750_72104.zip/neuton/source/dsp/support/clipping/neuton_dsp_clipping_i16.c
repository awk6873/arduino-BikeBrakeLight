#include <neuton/dsp/support/neuton_dsp_clipping.h>

#define CLIPPING_INPUT_TYPE     i16

#include <neuton/private/template/dsp/neuton_dsp_clipping_source.inc>