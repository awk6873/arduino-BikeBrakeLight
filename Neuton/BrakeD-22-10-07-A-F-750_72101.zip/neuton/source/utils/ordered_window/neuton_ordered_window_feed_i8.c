#include <neuton/utils/neuton_ordered_window.h>

#define FWIN_INPUT_TYPE     i8
#define FWIN_OUTPUT_TYPE    i8

#include <neuton/private/template/utils/neuton_ordered_window_feed_source.inc>