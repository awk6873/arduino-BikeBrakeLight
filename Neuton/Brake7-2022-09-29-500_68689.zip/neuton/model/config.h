/// Solution ID: 68689_Brake7-2022-09-29-500 | 2022-10-03T07:54:36Z ///

#ifndef NEUTON_CONFIG_H
#define NEUTON_CONFIG_H

#define CONTAINS_FFT_FEATURES 0
#define AUDIO_KWS_ENABLED 0

#include "model.h"
#include "dsp_config.h"

#endif // NEUTON_CONFIG_H

