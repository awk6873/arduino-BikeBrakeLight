#include <neuton/utils/neuton_ordered_window.h>

#define FWIN_INPUT_TYPE     i16
#define FWIN_OUTPUT_TYPE    i16

#include <neuton/private/template/utils/neuton_ordered_window_feed_source.inc>