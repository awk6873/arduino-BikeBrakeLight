/// Solution ID: 68662_Brake4-2022-09-29 | 2022-10-01T10:32:51Z ///

#ifndef NEUTON_CONFIG_H
#define NEUTON_CONFIG_H

#define CONTAINS_FFT_FEATURES 0
#define AUDIO_KWS_ENABLED 0

#include "model.h"
#include "dsp_config.h"

#endif // NEUTON_CONFIG_H

