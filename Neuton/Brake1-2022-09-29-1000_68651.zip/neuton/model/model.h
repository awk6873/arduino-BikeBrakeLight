/// Solution ID: 68651_Brake1 | 2022-09-30T16:50:37Z ///

#ifndef NEUTON_MODEL_MODEL_H
#define NEUTON_MODEL_MODEL_H

#ifdef __cplusplus
extern "C"
{
#endif

/* Model info */
#define NEUTON_MODEL_HEADER_VERSION 3
#define NEUTON_MODEL_QLEVEL 32
#define NEUTON_MODEL_FLOAT_SUPPORT 1
#define NEUTON_MODEL_TASK_TYPE 1  // binary classification
#define NEUTON_MODEL_NEURONS_COUNT 4
#define NEUTON_MODEL_WEIGHTS_COUNT 18
#define NEUTON_MODEL_INPUTS_COUNT 678
#define NEUTON_MODEL_INPUTS_COUNT_ORIGINAL 6
#define NEUTON_MODEL_INPUT_LIMITS_COUNT 678
#define NEUTON_MODEL_OUTPUTS_COUNT 2
#define NEUTON_MODEL_LOG_SCALE_OUTPUTS 0
#define NEUTON_MODEL_HAS_CLASSES_RATIO 0
#define NEUTON_MODEL_HAS_NEGPOS_RATIO 0

/* Preprocessing */
#define NEUTON_PREPROCESSING_ENABLED 1
#define NEUTON_MODEL_WINDOW_SIZE 100
#define NEUTON_DROP_ORIGINAL_FEATURES 0
#define NEUTON_BITMASK_ENABLED 1
#define NEUTON_INPUTS_IS_INTEGER 0
#define NEUTON_MODEL_SA_PRECISION 24

/* Types */
typedef float input_t;
typedef float extracted_feature_t;
typedef float coeff_t;
typedef float weight_t;
typedef float acc_signed_t;
typedef float acc_unsigned_t;
typedef uint16_t sources_size_t;
typedef uint8_t weights_size_t;
typedef uint8_t neurons_size_t;

/* Scaling */
static const input_t modelInputScaleMin[] = {
	-32868, -11610, -17840, -2195, -2288, -4943 };
static const input_t modelInputScaleMax[] = {
	32667, 16578, 32467, 1904, 4133, 3752 };

static const extracted_feature_t extractedFeaturesScaleMin[] = {
	103.25, 2.75, -3130.3201, -2548, -32868, 1.0034589, 978.91034, 31.287542,
	-4.7592845, -1.094234, 4, 2, 2, 133, 7.25, -2785.28, -742, -11610, 1.0008676,
	990.55963, 31.473158, -3.6808095, -1.5805148, 1, 0, 0, 186.375, 11.625,
	7542.3198, 7996, -17840, 1.0085899, 2046.266, 45.235672, -5.0436549, -0.99831057,
	10, 5, 5, 5.09375, 0.4375, -792.27002, -421, -2195, 1.0008676, 1.6850988,
	1.2981136, -2.9733098, -1.7745174, 1, 0, 0, 4.78125, 0.375, -403.35999,
	-39, -2288, 1.0008676, 1.4458985, 1.2024552, -2.7713468, -1.6335391, 1,
	0, 0, 4.40625, 0.34375, -1657.5699, -1029, -4943, 1.0008676, 1.1930993,
	1.0922909, -2.1052616, -1.699944, 1, 0, 0 };
static const extracted_feature_t extractedFeaturesScaleMax[] = {
	45523, 2323.6719, 1207.52, 32667, 1108, 1.058154, 82089424, 9060.3213,
	2.2566531, 31.663746, 72, 36, 36, 23970.75, 5646.125, 2088.0801, 16578,
	1702, 1.0566412, 11863048, 3444.2776, 6.5783014, 54.518623, 70, 35, 35,
	45004.375, 6932, 9612.9199, 32467, 7924, 1.0505385, 78308680, 8849.2188,
	7.4729924, 65.7976, 62, 31, 31, 2809.125, 2254.4375, 708.65002, 1904, 468,
	1.0420066, 916867.06, 957.53174, 2.2212794, 9.4212389, 51, 26, 25, 3816.75,
	1278.125, 820.92999, 4133, 435, 1.0420066, 1172389.9, 1082.7695, 2.8087962,
	16.056143, 51, 25, 26, 3246.375, 5579.375, 2037.0699, 3752, 1483, 1.0451286,
	6022029.5, 2453.9824, 3.1394973, 19.734573, 55, 27, 28 };

/* Limits */
static const uint8_t modelUsedInputsMask[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x10, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x04, 0x80, 0x01, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00,
	0x00 };

/* Structure */
static const weight_t modelWeights[] = {
	-0.011259004, 0.068521246, 0.98965013, -0.62780249, 0.30323759, 0.25193644,
	-0.08203125, 0.43075979, -0.056091189, 0.21749473, 0.84258938, -0.2874383,
	-0.50995845, -0.37268949, 0.99995947, 0.048995733, -0.69913614, 0.044032037 };

static const sources_size_t modelLinks[] = {
	62, 124, 403, 602, 615, 650, 678, 0, 678, 0, 131, 183, 266, 602, 616, 678,
	2, 678 };

static const weights_size_t modelIntLinksBoundaries[] = { 0, 8, 10, 17 };
static const weights_size_t modelExtLinksBoundaries[] = { 7, 9, 16, 18 };

static const coeff_t modelFuncCoeffs[] = {
	39.999943, 23.303986, 38.753067, 33.048779 };
static const uint8_t modelFuncTypes[] = { 0, 0, 0, 0 };

static const neurons_size_t modelOutputNeurons[] = { 1, 3 };

#ifdef __cplusplus
}
#endif

#endif // NEUTON_MODEL_MODEL_H

