/// Solution ID: 68651_Brake1 | 2022-09-30T16:50:37Z ///

#ifndef NEUTON_CONFIG_H
#define NEUTON_CONFIG_H

#define CONTAINS_FFT_FEATURES 0
#define AUDIO_KWS_ENABLED 0

#include "model.h"
#include "dsp_config.h"

#endif // NEUTON_CONFIG_H

