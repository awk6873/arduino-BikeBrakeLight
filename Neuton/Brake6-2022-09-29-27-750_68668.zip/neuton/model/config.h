/// Solution ID: 68668_Brake6-2022-09-29 | 2022-10-01T14:14:05Z ///

#ifndef NEUTON_CONFIG_H
#define NEUTON_CONFIG_H

#define CONTAINS_FFT_FEATURES 0
#define AUDIO_KWS_ENABLED 0

#include "model.h"
#include "dsp_config.h"

#endif // NEUTON_CONFIG_H

