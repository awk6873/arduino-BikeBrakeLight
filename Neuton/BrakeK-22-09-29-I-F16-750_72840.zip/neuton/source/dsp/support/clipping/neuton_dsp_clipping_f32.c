#include <neuton/dsp/support/neuton_dsp_clipping.h>

#define CLIPPING_INPUT_TYPE     f32

#include <neuton/private/template/dsp/neuton_dsp_clipping_source.inc>