/**
 *
 * @defgroup neuton_version Version
 * @{
 *
 * @brief
 *
 */

#ifndef _NEUTON_VERSION_H_
#define _NEUTON_VERSION_H_

#define NEUTON_MAJOR_VERSION        1
#define NEUTON_MINOR_VERSION        1
#define NEUTON_PATCH_VERSION        0
#define NEUTON_BUILD_NUMBER         0

#endif /* _NEUTON_VERSION_H_ */

/**
 * @}
 */
