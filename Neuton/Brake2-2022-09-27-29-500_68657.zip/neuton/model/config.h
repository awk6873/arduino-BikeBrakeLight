/// Solution ID: 68657_Brake2-2022-09-27 | 2022-10-01T05:05:08Z ///

#ifndef NEUTON_CONFIG_H
#define NEUTON_CONFIG_H

#define CONTAINS_FFT_FEATURES 0
#define AUDIO_KWS_ENABLED 0

#include "model.h"
#include "dsp_config.h"

#endif // NEUTON_CONFIG_H

