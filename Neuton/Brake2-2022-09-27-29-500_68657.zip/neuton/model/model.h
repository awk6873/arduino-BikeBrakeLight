/// Solution ID: 68657_Brake2-2022-09-27 | 2022-10-01T05:05:08Z ///

#ifndef NEUTON_MODEL_MODEL_H
#define NEUTON_MODEL_MODEL_H

#ifdef __cplusplus
extern "C"
{
#endif

/* Model info */
#define NEUTON_MODEL_HEADER_VERSION 3
#define NEUTON_MODEL_QLEVEL 32
#define NEUTON_MODEL_FLOAT_SUPPORT 1
#define NEUTON_MODEL_TASK_TYPE 1  // binary classification
#define NEUTON_MODEL_NEURONS_COUNT 5
#define NEUTON_MODEL_WEIGHTS_COUNT 26
#define NEUTON_MODEL_INPUTS_COUNT 378
#define NEUTON_MODEL_INPUTS_COUNT_ORIGINAL 6
#define NEUTON_MODEL_INPUT_LIMITS_COUNT 378
#define NEUTON_MODEL_OUTPUTS_COUNT 2
#define NEUTON_MODEL_LOG_SCALE_OUTPUTS 0
#define NEUTON_MODEL_HAS_CLASSES_RATIO 0
#define NEUTON_MODEL_HAS_NEGPOS_RATIO 0

/* Preprocessing */
#define NEUTON_PREPROCESSING_ENABLED 1
#define NEUTON_MODEL_WINDOW_SIZE 50
#define NEUTON_DROP_ORIGINAL_FEATURES 0
#define NEUTON_BITMASK_ENABLED 1
#define NEUTON_INPUTS_IS_INTEGER 0
#define NEUTON_MODEL_SA_PRECISION 24

/* Types */
typedef float input_t;
typedef float extracted_feature_t;
typedef float coeff_t;
typedef float weight_t;
typedef float acc_signed_t;
typedef float acc_unsigned_t;
typedef uint16_t sources_size_t;
typedef uint8_t weights_size_t;
typedef uint8_t neurons_size_t;

/* Scaling */
static const input_t modelInputScaleMin[] = {
	-23280, -15902, -12104, -1282, -1607, -3950 };
static const input_t modelInputScaleMax[] = {
	32667, 24634, 32467, 1219, 1745, 4967 };

static const extracted_feature_t extractedFeaturesScaleMin[] = {
	131.375, 7.375, -3564.1599, -2180, -23280, 1.002041, 1350.2786, 36.746136,
	-5.2308679, -1.3657813, 1, 0, 1, 105.25, 13.375, -3054.3201, -2390, -15902,
	1.002041, 1809.8171, 42.541946, -4.5910945, -1.5016886, 1, 0, 0, 140.75,
	8.25, 6923.2798, 7680, -12104, 1.0101272, 2777.7588, 52.704449, -6.0095506,
	-1.2315304, 5, 3, 2, 6.625, 1.15625, -802.32001, -497, -1282, 1.002041,
	4.718401, 2.172188, -2.166471, -1.9032292, 1, 0, 0, 6.40625, 0.8125, -398.34,
	-260, -1607, 1.002041, 6.5599999, 2.5612497, -2.1022964, -1.7887313, 1,
	0, 0, 15.34375, 3.4375, -2149.8799, -1702, -3950, 1.002041, 45.107601,
	6.7162194, -3.2066467, -1.8858999, 1, 0, 0 };
static const extracted_feature_t extractedFeaturesScaleMax[] = {
	41656.5, 2767.75, 991.91998, 32667, 672, 1.0691706, 1.4646296e+08, 12102.188,
	5.0311856, 32.800968, 36, 18, 18, 20479.875, 2709.625, 2084.1599, 24634,
	1310, 1.0709831, 13040691, 3611.1897, 6.6425462, 43.115845, 37, 18, 19,
	41667.25, 2745.125, 9107.1201, 32467, 8056, 1.0637025, 85353592, 9238.7012,
	6.7171893, 43.763901, 33, 16, 17, 1379.2188, 986.46875, 908.65997, 1219,
	457, 1.0317668, 606383.19, 778.70612, 2.2163241, 5.5522442, 16, 8, 8, 1968.9375,
	690.6875, 953.12, 1745, 485, 1.0356138, 463949.69, 681.13855, 2.0769908,
	4.8658009, 18, 9, 9, 2272.1875, 2477.0938, 2121.72, 4967, 1470, 1.0317668,
	3894151.8, 1973.3605, 2.6544545, 15.2687, 16, 8, 8 };

/* Limits */
static const uint8_t modelUsedInputsMask[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x00, 0x18, 0x10, 0x04,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00,
	0x00, 0x50, 0x08, 0x08, 0x09, 0x90, 0x00, 0x00, 0x00, 0x00, 0x08, 0x02 };

/* Structure */
static const weight_t modelWeights[] = {
	0.54458427, -0.18645352, -0.9999994, 0.4926804, 0.42134064, 0.40616757,
	0.26454327, -0.15479584, 0.99647897, -0.27942193, 0.11880302, -0.16146046,
	0.99999762, -0.3626194, -0.7029286, 0.095616065, 0.60227066, 0.21128006,
	-0.5488435, -0.99854344, 1, 0.38657755, -0.11494064, 0.47824171, 0.99724811,
	-0.063634783 };

static const sources_size_t modelLinks[] = {
	53, 90, 302, 320, 371, 378, 0, 53, 76, 307, 315, 323, 332, 378, 1, 378,
	75, 84, 259, 300, 335, 377, 378, 0, 3, 378 };

static const weights_size_t modelIntLinksBoundaries[] = { 0, 7, 15, 16, 25 };
static const weights_size_t modelExtLinksBoundaries[] = { 6, 14, 16, 23, 26 };

static const coeff_t modelFuncCoeffs[] = {
	40, 22.543736, 11.620655, 40, 16.573521 };
static const uint8_t modelFuncTypes[] = { 0, 0, 0, 0, 0 };

static const neurons_size_t modelOutputNeurons[] = { 4, 2 };

#ifdef __cplusplus
}
#endif

#endif // NEUTON_MODEL_MODEL_H

