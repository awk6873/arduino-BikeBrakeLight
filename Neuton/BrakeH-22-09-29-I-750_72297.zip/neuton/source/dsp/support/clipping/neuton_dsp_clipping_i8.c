#include <neuton/dsp/support/neuton_dsp_clipping.h>

#define CLIPPING_INPUT_TYPE     i8

#include <neuton/private/template/dsp/neuton_dsp_clipping_source.inc>