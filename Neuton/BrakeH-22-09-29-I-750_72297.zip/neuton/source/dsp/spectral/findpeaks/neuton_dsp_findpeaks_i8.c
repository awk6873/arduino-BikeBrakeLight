#include <neuton/dsp/spectral/neuton_dsp_findpeaks.h>

#define FPEAKS_INPUT_TYPE     i8

#include <neuton/private/template/dsp/neuton_dsp_findpeaks_source.inc>